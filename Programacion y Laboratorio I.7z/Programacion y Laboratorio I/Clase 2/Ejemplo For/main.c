#include <stdio.h>
#include <stdlib.h>

int main()
{

    int edad;
    int contEdades=0;
    int acumEdades=0;
    int i;
    float promEdades;
    char seguir;

    //for(inicializacion de la variable de control; condicion continuidad de bucle; incremento de la variable de control)
   /*for(i=0; i<5; i++)
    {
        printf("Ingrese edad: ");
        scanf("%d", &edad);

        acumEdades +=edad; // acumEdades = acumEdades + edad;
    }

    promEdades = (float)acumEdades/i;

    printf("El promedio de edades es: %f", promEdades);*/

    printf("\nFOR en incremento\n");

    for(i=0; i<10; i++)
    {
            printf("%d\n", i+1);
    }
    printf("\nFOR en decremento\n");
    for(i=10; i>0; i--)
    {
        printf("%d\n", i);
    }
    return 0;
}
